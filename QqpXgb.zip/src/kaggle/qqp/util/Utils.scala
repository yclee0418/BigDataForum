package kaggle.qqp.util
import org.apache.spark.sql.{ SparkSession, Dataset, DataFrame }

object Utils {
  def createSparkSession(masterUrl: String, appName: String): SparkSession = {
    val spark = SparkSession
      .builder().master(masterUrl)
      .appName(appName)
      .config("spark.executor.memory","2g")
      //.config("spark.some.config.option", "some-value")
      .getOrCreate()
    spark
  }

  def readCSV(spark: SparkSession, filePath: String): DataFrame = {
    val df = spark.read
      .format("csv")
      .option("header", "true") //reading the headers
      .option("mode", "DROPMALFORMED")
      .csv(filePath)
    df
  }
  
  def mlVectorToMllibVector(features: org.apache.spark.ml.linalg.Vector): org.apache.spark.mllib.linalg.Vector = {
    var dense: org.apache.spark.ml.linalg.DenseVector = null
    if (features.isInstanceOf[org.apache.spark.ml.linalg.DenseVector]){
      dense = features.asInstanceOf[org.apache.spark.ml.linalg.DenseVector]
    } else if (features.isInstanceOf[org.apache.spark.ml.linalg.SparseVector]) {
      val sparse = features.asInstanceOf[org.apache.spark.ml.linalg.SparseVector]
      dense = sparse.toDense
    }
    val ss = dense.toSparse
    //val vec: org.apache.spark.mllib.linalg.Vector = org.apache.spark.mllib.linalg.Vectors.dense(dense.toArray)
    val vec: org.apache.spark.mllib.linalg.Vector = org.apache.spark.mllib.linalg.Vectors.sparse(ss.size, ss.indices, ss.values)
    vec
  }
}