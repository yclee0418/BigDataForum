package kaggle.qqp.main

import org.joda.time._
//log
import org.apache.log4j.Logger
import org.apache.log4j.Level
import org.apache.log4j._

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._
import org.apache.spark.rdd._

import kaggle.qqp.util._
import org.apache.spark.sql._
import org.apache.spark.sql.functions.{ col => col, split => split, when => when, udf => udf }

import org.apache.spark.ml.feature.{ HashingTF, IDF, Word2Vec, Word2VecModel, VectorAssembler }
import org.apache.spark.ml.{ Pipeline, PipelineModel }
import org.apache.spark.ml.param.ParamMap

import ml.dmlc.xgboost4j.scala.{ Booster, DMatrix }
import ml.dmlc.xgboost4j.scala.spark.{ DataUtils, XGBoost, XGBoostModel }
import org.apache.spark.mllib.linalg.{ DenseVector => MLDenseVector }
import org.apache.spark.mllib.regression.{ LabeledPoint => MLLabeledPoint }
import org.apache.spark.mllib.util.MLUtils

object QqpXgboost {
  def main(args: Array[String]): Unit = {
    if (args == null || args.size != 8) {
      println("[Error]Need 8 args: <masterUrl> <trainFilePath> <testFilePath> <outputPath> <debug(Y/N)> <nRound> <nWorkers> <maxDepth>")
      return
    }

    setLogger
    val numFeatures = 128
    val numW2vFeatures = 20
    val masterUrl = args(0)
    val trainFilePath = args(1)
    val testFilePath = args(2)
    val outputDir = args(3)
    val isDebug = "Y".equals(args(4))

    val numRound = args(5).toInt //1000 //3000
    val numWorkers = args(6).toInt //4
    val maxDepth = args(7).toInt //40
    //train-logloss:0.170095 2800-20-128(w2vWeight only, act: )
    //train-logloss:0.227077 2800-20-256(w2vWeight only, act: )
    //train-logloss:0.202168 2400-20(+w2vWeight, act: )
    //train-logloss:0.183637 2400-20(w2vWeight only, act: )
    //train-logloss:0.137635 1200-40(act: )
    //train-logloss:0.156666 1000-40(act:0.37459)
    //train-logloss:0.176111 800-40(act:0.37482)
    //train-logloss:0.200469 600-40(act:0.37732)
    //train-logloss:0.197974 600-40(w2v, act: 
    //train-logloss:0.22854  400-40(act:0.38254)
    //train-logloss:0.201278 400-40(+w2vWeight, act: 0.39187)
    //train-logloss:0.239765 320-40(act:0.38527)
    //train-logloss:0.275656 200-40(act: 0.39423)
    //train-logloss:0.252041 200-40(+w2vWeight, )
    //train-logloss:???      160-40(act: 0.40140)
    //train-logloss:0.274895 160-40(+w2vWeight, 
    //train-logloss:0.335688 100-40(+w2vWeight, 
    //train-logloss:0.548461 50-10
    //train-logloss:0.435741 60-40(+w2vWeight, 
    //train-logloss:0.512567 50-20
    //train-logloss:0.518901 80-10
    val spark = Utils.createSparkSession(masterUrl, "Kaggle QuoraQuestion Xgboost04")
    spark.sparkContext.setCheckpointDir("data/checkpoint")
    val (trainData, testData) = prepareData(spark, trainFilePath, testFilePath, isDebug)
    //tf-idf
    val trainTfIdfData = calculateTfIdfForTrain(trainData, numFeatures, numW2vFeatures, isDebug)
    val testTfIdfData = calculateTfIdfForTest(testData, numFeatures, numW2vFeatures, isDebug)

    //word2Vec
    //val trainTfIdfData = calculateW2VForTrain(trainData, numW2vFeatures, isDebug)
    //val testTfIdfData = calculateW2VForTest(testData, numW2vFeatures, isDebug)
    val assemblerInputs = Array("weight","w2vDist", "features1", "features2" /*, "featuresWv1", "featuresWv2"*/ )

    val trainDataRdd = transferTrainDfToLabeledPoint(trainTfIdfData, assemblerInputs, isDebug)
    val testDataRdd = transferTestDfToLabeledPoint(testTfIdfData, assemblerInputs, isDebug)

    trainDataRdd.persist(); testDataRdd.persist()
    
    val model = trainXgbModel(trainDataRdd, numRound, numWorkers, maxDepth)
    
    trainDataRdd.unpersist()
    doPredict(model, testDataRdd, numWorkers, outputDir)

    testDataRdd.unpersist()
    println("finished ...")
  }

  def calculateW2vDistance(df: DataFrame, isDebug: Boolean): DataFrame = {
    val calculateDistance = udf((vec1: org.apache.spark.ml.linalg.Vector, vec2: org.apache.spark.ml.linalg.Vector) => {
      val dist = org.apache.spark.ml.linalg.Vectors.sqdist(vec1, vec2)
      dist
    })
    val newDf = df.withColumn("w2vDist", calculateDistance(col("featuresWv1"), col("featuresWv2"))).drop("featuresWv1", "featuresWv2")
    if (isDebug) {
      newDf.printSchema()
    }
    newDf
  }

  def transferTrainDfToLabeledPoint(trainData: DataFrame, assemblerInputs: Array[String], isDebug: Boolean): RDD[MLLabeledPoint] = {
    val start = new DateTime()
    println("starting transfer train dataframe to RDD ...")

    val assembler: VectorAssembler = new VectorAssembler().setInputCols(assemblerInputs).setOutputCol("features")
    val featureDf = assembler.transform(trainData)
    if (isDebug)
      featureDf.show(3, false)
    val rtnRdd = featureDf.rdd.map(row => MLLabeledPoint(
      row.getAs[Double]("is_duplicate"),
      Utils.mlVectorToMllibVector(row.getAs[org.apache.spark.ml.linalg.Vector]("features"))))
    val duration = new Duration(start, new DateTime())
    println("finish transfer train dataframe to RDD, duration = %d".format(duration.getMillis))
    rtnRdd
  }

  def transferTestDfToLabeledPoint(testData: DataFrame, assemblerInputs: Array[String], isDebug: Boolean): RDD[MLLabeledPoint] = {
    val start = new DateTime()
    println("starting transfer test dataframe to RDD ...")
    val assembler: VectorAssembler = new VectorAssembler().setInputCols(assemblerInputs).setOutputCol("features")
    val featureDf = assembler.transform(testData)
    if (isDebug)
      featureDf.show(3, false)
    val rtnRdd = featureDf.rdd.map(row => MLLabeledPoint(
      row.getAs[String]("test_id").toDouble,
      Utils.mlVectorToMllibVector(row.getAs[org.apache.spark.ml.linalg.Vector]("features"))))
    val duration = new Duration(start, new DateTime())
    println("finish transfer test dataframe to RDD, duration = %d".format(duration.getMillis))
    rtnRdd
  }

  def doPredict(xgbModel: XGBoostModel, testRddOrg: RDD[MLLabeledPoint], nWorkers: Int, outputDir: String) = {
    val start = new DateTime()
    println("starting predict test RDD ...")
    val testRdd = testRddOrg /*.filter(f => f.label < 200)*/ .sortBy(f => f.label, true, nWorkers)
    val testSet = testRdd.map(f => f.features)
    //val idRdd = testRdd.map(f => f.label.toInt)
    //println("cnt1: %d, cnt2: %d".format(testSet.count(), idRdd.count()))
    //val matrix: DMatrix = new DMatrix(testRdd)
    val predRes = xgbModel.predict(testSet).flatMap(f => f.flatMap(f => f))
    //val outputRes = idRdd.zip(predRes).map(f => (f._1 + "," + f._2))
    val outputRes = predRes.zipWithIndex().map(f => (f._2 + "," + f._1))
    //    val outputRes = idRdd.zipPartitions(predRes){
    //      (rdd1Iter,rdd2Iter) => {
    //        var result = List[String]()
    //              while(rdd1Iter.hasNext && rdd2Iter.hasNext) {
    //               result::=(rdd1Iter.next() + "," + rdd2Iter.next())
    //              }
    //              result.iterator
    //      }
    //    }
    //println("cnt1: %d, cnt2: %d".format(predRes.count(), outputRes.count()))
    outputRes.repartition(8 * nWorkers).saveAsTextFile("%s".format(outputDir))
    val duration = new Duration(start, new DateTime())
    println("finish predict test RDD, duration = %d".format(duration.getMillis))
  }

  def trainXgbModel(trainRDD: RDD[MLLabeledPoint], numRound: Int, nWorkers: Int, maxDepth: Int): XGBoostModel = {
    val start = new DateTime()
    println("starting train model for train RDD ...")
    val paramMap = List(
      "eta" -> 0.02f,
      "max_depth" -> maxDepth,
      "objective" -> "binary:logistic",
      "eval_metric" -> "logloss").toMap
    val xgboostModel = XGBoost.train(trainRDD.repartition(nWorkers), paramMap, numRound, nWorkers = nWorkers)
    val duration = new Duration(start, new DateTime())
    println("finish train model for train RDD, duration = %d".format(duration.getMillis))
    xgboostModel
  }

  def prepareData(spark: SparkSession, trainFilePath: String, testFilePath: String, isDebug: Boolean): (DataFrame, DataFrame) = {
    val showNum = 3
    val start = new DateTime()
    println("importing train data ...")
    val df = Utils.readCSV(spark, trainFilePath)
    val dfTrain = df.select(col("id"),
      col("qid1"), when(col("words1") !== (""), split(col("words1"), "-")).otherwise(Array(".")).alias("words1"),
      col("qid2"), when(col("words2") !== "", split(col("words2"), "-")).otherwise(Array(".")).alias("words2"),
      col("is_duplicate").cast(types.DataTypes.DoubleType),
      col("weight").cast(types.DataTypes.DoubleType))
    if (isDebug) {
      dfTrain.printSchema()
      dfTrain.show(showNum, false)
      //println("Total train data count: %d".format(dfTrain.count())) //Total train data count: 404290
    }

    println("importing test data ...")
    val df2 = Utils.readCSV(spark, testFilePath)
    val dfTest = df2.select(col("test_id"),
      when(col("words1") !== (""), split(col("words1"), "-")).otherwise(Array(".")).alias("words1"),
      when(col("words2") !== "", split(col("words2"), "-")).otherwise(Array(".")).alias("words2"),
      col("weight").cast(types.DataTypes.DoubleType))
    if (isDebug) {
      dfTest.printSchema()
      dfTest.show(showNum, false)
      //println("Total test data count: %d".format(dfTest.count())) //Total test data count: 2345796
    }
    val duration = new Duration(start, new DateTime())
    println("finish import data, duration = %d".format(duration.getMillis))
    (dfTrain, dfTest)
  }

  def getTfIdfTransformer(numFeatures: Int): (HashingTF, IDF) = {
    val hashingTF = new HashingTF()
      .setInputCol("words").setOutputCol("rawFeatures").setNumFeatures(numFeatures)
    val idf = new IDF().setInputCol("rawFeatures").setOutputCol("features")
    (hashingTF, idf)
  }

  def getWord2VecTransformer(numW2VFeatures: Int): Word2Vec = {
    val word2Vec = new Word2Vec()
      .setInputCol("words")
      .setOutputCol("featuresW2V")
      .setVectorSize(numW2VFeatures)
      .setMinCount(2)
    word2Vec
  }

  def getW2VModel(df: DataFrame, numW2vFeatures: Int, isDebug: Boolean): Word2VecModel = {
    val w2v = getWord2VecTransformer(numW2vFeatures)
    val w2vModel = w2v.fit(df)
    w2vModel
  }

  def calculateW2VForTrain(dfTrain: DataFrame, numW2vFeatures: Int, isDebug: Boolean): DataFrame = {
    println("calculate w2v weight for train data ...")
    val start = new DateTime()
    val showNum = 3
    var wordsDf1 = dfTrain.select(col("id"),
      col("qid1"), col("words1").alias("words"), col("weight"), col("is_duplicate"))
    var wordsDf2 = dfTrain.select(col("id"), col("qid2"), col("words2").alias("words"))
    val wordsDfAll = wordsDf1.select("id", "words")
      .union(wordsDf2.select("id", "words")).filter(!col("words").isNull)

    //Add Word2Vec feature
    val w2vModel = getW2VModel(wordsDfAll, numW2vFeatures, isDebug)
    wordsDf1 = w2vModel.transform(wordsDf1)
    wordsDf2 = w2vModel.transform(wordsDf2)

    val trainW2vData =
      wordsDf1.select(col("id"), col("qid1"), /* col("features").alias("features1"),*/
        col("weight").cast("double"), col("is_duplicate"), col("featuresW2V").alias("featuresWv1"))
        .join(wordsDf2.select(col("id"), col("qid2"), /*col("features").alias("features2"), */
          col("featuresW2V").alias("featuresWv2")),
          Seq("id")).drop("wordsDf2.id")
    if (isDebug) {
      trainW2vData.printSchema()
      //trainTfidfData.show(showNum)
    }
    val duration = new Duration(start, new DateTime())
    println("finish calculate W2v for train data, duration = %d".format(duration.getMillis))
    trainW2vData
  }

  def calculateW2VForTest(dfTest: DataFrame, numW2vFeatures: Int, isDebug: Boolean): DataFrame = {
    val showNum = 3
    println("calculate W2v weight for test data ...")
    val start = new DateTime()
    var wordsDf1 = dfTest.select(col("test_id"), col("words1").alias("words"), col("weight"))
    var wordsDf2 = dfTest.select(col("test_id"), col("words2").alias("words"))
    val wordsDfAll = wordsDf1.select("test_id", "words")
      .union(wordsDf2.select("test_id", "words"))

    //Add Word2Vec feature
    val w2vModel = getW2VModel(wordsDfAll, numW2vFeatures, isDebug)
    wordsDf1 = w2vModel.transform(wordsDf1)
    wordsDf2 = w2vModel.transform(wordsDf2)

    val testW2vData =
      wordsDf1.select(col("test_id"), /*col("features").alias("features1"),*/ col("weight").cast("double"),
        col("featuresW2V").alias("featuresWv1"))
        .join(wordsDf2.select(col("test_id"), /*col("features").alias("features2"),*/ col("featuresW2V").alias("featuresWv2")),
          Seq("test_id")).drop("wordsDf1.test_id")
    if (isDebug) {
      testW2vData.printSchema()
      //testTfidfData.show(showNum)
    }
    val duration = new Duration(start, new DateTime())
    println("finish calculate W2v for test data, duration = %d".format(duration.getMillis))
    testW2vData
  }

  def calculateTfIdfForTrain(dfTrain: DataFrame, numFeatures: Int, numW2vFeatures: Int, isDebug: Boolean): DataFrame = {
    println("calculate tf-idf weight for train data ...")
    val start = new DateTime()
    val showNum = 3
    var wordsDf1 = dfTrain.select(col("id"),
      col("qid1"), col("words1").alias("words"), col("weight"), col("is_duplicate"))
    var wordsDf2 = dfTrain.select(col("id"), col("qid2"), col("words2").alias("words"))
    val (hashingTF, idf) = getTfIdfTransformer(numFeatures)
    val wordsDfAll = wordsDf1.select("id", "words")
      .union(wordsDf2.select("id", "words")).filter(!col("words").isNull)
    val featurizedData = hashingTF.transform(wordsDfAll)
    val idfModel = idf.fit(featurizedData)
    wordsDf1 = idfModel.transform(hashingTF.transform(wordsDf1))
    wordsDf2 = idfModel.transform(hashingTF.transform(wordsDf2))

    //Add Word2Vec feature
    val w2v = getWord2VecTransformer(numW2vFeatures)
    val w2vModel = w2v.fit(wordsDfAll)
    wordsDf1 = w2vModel.transform(wordsDf1)
    wordsDf2 = w2vModel.transform(wordsDf2)

    val trainTfidfData =
      wordsDf1.select(col("id"), col("qid1"), col("features").alias("features1"),
        col("weight").cast("double"), col("is_duplicate"), col("featuresW2V").alias("featuresWv1"))
        .join(wordsDf2.select(col("id"), col("qid2"), col("features").alias("features2"),
          col("featuresW2V").alias("featuresWv2")),
          Seq("id")).drop("wordsDf2.id")
    if (isDebug) {
      trainTfidfData.printSchema()
      //trainTfidfData.show(showNum)
    }
    val trainDataFinal = calculateW2vDistance(trainTfidfData, isDebug)
    val duration = new Duration(start, new DateTime())
    println("finish calculate tf-idf for train data, duration = %d".format(duration.getMillis))
    trainDataFinal
  }

  def calculateTfIdfForTest(dfTest: DataFrame, numFeatures: Int, numW2vFeatures: Int, isDebug: Boolean): DataFrame = {
    val showNum = 3
    println("calculate tf-idf weight for test data ...")
    val start = new DateTime()
    var wordsDf1 = dfTest.select(col("test_id"), col("words1").alias("words"), col("weight"))
    var wordsDf2 = dfTest.select(col("test_id"), col("words2").alias("words"))
    val (hashingTF, idf) = getTfIdfTransformer(numFeatures)
    val wordsDfAll = wordsDf1.select("test_id", "words")
      .union(wordsDf2.select("test_id", "words"))
    val featurizedData = hashingTF.transform(wordsDfAll)
    val idfModel = idf.fit(featurizedData)
    wordsDf1 = idfModel.transform(hashingTF.transform(wordsDf1))
    wordsDf2 = idfModel.transform(hashingTF.transform(wordsDf2))

    //Add Word2Vec feature
    val w2v = getWord2VecTransformer(numW2vFeatures)
    val w2vModel = w2v.fit(wordsDfAll)
    wordsDf1 = w2vModel.transform(wordsDf1)
    wordsDf2 = w2vModel.transform(wordsDf2)

    val testTfidfData =
      wordsDf1.select(col("test_id"), col("features").alias("features1"), col("weight").cast("double"),
        col("featuresW2V").alias("featuresWv1"))
        .join(wordsDf2.select(col("test_id"), col("features").alias("features2"), col("featuresW2V").alias("featuresWv2")),
          Seq("test_id")).drop("wordsDf1.test_id")
    if (isDebug) {
      testTfidfData.printSchema()
      //testTfidfData.show(showNum)
    }
    val testDataFinal = calculateW2vDistance(testTfidfData, isDebug)
    val duration = new Duration(start, new DateTime())
    println("finish calculate tf-idf for test data, duration = %d".format(duration.getMillis))
    testDataFinal
  }

  def splitTrainData(trainData: DataFrame): (DataFrame, DataFrame) = {
    println("Split train data into trainSet and validSet ...")
    val start = new DateTime()
    val weights = Array(0.9, 0.1)
    val seed = 1126
    val trainData0 = trainData.filter("is_duplicate=0")
    val trainData1 = trainData.filter("is_duplicate=1")
    val train0S = trainData0.randomSplit(weights, seed)
    val train1S = trainData1.randomSplit(weights, seed)
    val duration = new Duration(start, new DateTime())
    println("finish split train data, duration = %d".format(duration.getMillis))
    (train0S(0).union(train1S(0)), train0S(1).union(train1S(1)))
  }

  def setLogger = {
    Logger.getLogger("org").setLevel(Level.OFF)
    Logger.getLogger("com").setLevel(Level.OFF)
    Logger.getLogger("io").setLevel(Level.OFF)
    //System.setProperty("spark.ui.showConsoleProgress", "false")
    Logger.getRootLogger().setLevel(Level.DEBUG);
  }
}
