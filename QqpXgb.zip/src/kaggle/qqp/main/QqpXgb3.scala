package kaggle.qqp.main

import org.joda.time._
//log
import org.apache.log4j.Logger
import org.apache.log4j.Level
import org.apache.log4j._

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._
import org.apache.spark.rdd._

import kaggle.qqp.util._
import org.apache.spark.sql._
import org.apache.spark.sql.functions.{ col => col, split => split, when => when, udf => udf }

import org.apache.spark.ml.feature.{ HashingTF, IDF, Word2Vec, Word2VecModel, VectorAssembler }
import org.apache.spark.ml.{ Pipeline, PipelineModel }
import org.apache.spark.ml.param.ParamMap
import org.apache.spark.ml.feature.PCA

import ml.dmlc.xgboost4j.scala.{ Booster, DMatrix }
import ml.dmlc.xgboost4j.scala.spark.{ DataUtils, XGBoost, XGBoostModel }
import org.apache.spark.mllib.linalg.{ DenseVector => MLDenseVector }
import org.apache.spark.mllib.regression.{ LabeledPoint => MLLabeledPoint }
import org.apache.spark.mllib.util.MLUtils

object QqpXgb3 {
  def main(args: Array[String]): Unit = {
    if (args == null || args.size != 10) {
      println("[Error]Need 8 args: <masterUrl> <trainFilePath> <testFilePath> <outputPath> <debug(Y/N)> <nRound> <nWorkers> <maxDepth> <FeatureNum> <pcaFeatureNum>")
      return
    }

    setLogger
    val numFeatures = args(8).toInt
    val numPcaFeatures = args(9).toInt
    val numW2vFeatures = 20
    val masterUrl = args(0)
    val trainFilePath = args(1)
    val testFilePath = args(2)
    val outputDir = args(3)
    val isDebug = "Y".equals(args(4))

    val numRound = args(5).toInt //1000 //3000
    val numWorkers = args(6).toInt //4
    val maxDepth = args(7).toInt //40

    val spark = Utils.createSparkSession(masterUrl, "Kaggle QuoraQuestion Xgboost3 04")
    spark.sparkContext.setCheckpointDir("data/checkpoint")
    val (trainData, testData) = prepareData(spark, trainFilePath, testFilePath, isDebug)
    //tf-idf
    //val trainTfIdfData = calculateTfIdfForTrain(trainData, numFeatures, numW2vFeatures, isDebug)
    //val testTfIdfData = calculateTfIdfForTest(testData, numFeatures, numW2vFeatures, isDebug)
    //tf-idf2
    val (trainTfIdfData, testTfIdfData) = addTfidfFeatures(trainData, testData, numFeatures, numPcaFeatures, isDebug)
    
    val assemblerInputs = Array( /**/"weight", "w2vWeight", "w2vWeight1k", 
        "features1", "features2" /*, "featuresWv1", "featuresWv2"*/ )

    val trainDataRdd = transferTrainDfToLabeledPoint(trainTfIdfData, assemblerInputs, isDebug)
    val testDataRdd = transferTestDfToLabeledPoint(testTfIdfData, assemblerInputs, isDebug)

    trainDataRdd.persist(); testDataRdd.persist()

    val model = trainXgbModel(trainDataRdd, numRound, numWorkers, maxDepth)

    trainDataRdd.unpersist()
    doPredict(model, testDataRdd, numWorkers, outputDir)

    testDataRdd.unpersist()
    println("finished ...")
  }

  def prepareData(spark: SparkSession, trainFilePath: String, testFilePath: String, isDebug: Boolean): (DataFrame, DataFrame) = {
    val showNum = 3
    val start = new DateTime()
    println("importing train data ...")
    val df = Utils.readCSV(spark, trainFilePath)
    val dfTrain = df.select(col("id"),
      col("qid1"), when(col("words1") !== (""), split(col("words1"), "-")).otherwise(Array(".")).alias("words1"),
      col("qid2"), when(col("words2") !== "", split(col("words2"), "-")).otherwise(Array(".")).alias("words2"),
      col("is_duplicate").cast(types.DataTypes.DoubleType),
      col("weight").cast(types.DataTypes.DoubleType), col("w2vWeight").cast(types.DataTypes.DoubleType),
      col("w2vWeight1k").cast(types.DataTypes.DoubleType))
    if (isDebug) {
      dfTrain.printSchema()
      dfTrain.show(showNum, false)
      //println("Total train data count: %d".format(dfTrain.count())) //Total train data count: 404290
    }

    println("importing test data ...")
    val df2 = Utils.readCSV(spark, testFilePath)
    val dfTest = df2.select(col("test_id"),
      when(col("words1") !== (""), split(col("words1"), "-")).otherwise(Array(".")).alias("words1"),
      when(col("words2") !== "", split(col("words2"), "-")).otherwise(Array(".")).alias("words2"),
      col("weight").cast(types.DataTypes.DoubleType), col("w2vWeight").cast(types.DataTypes.DoubleType),
      col("w2vWeight1k").cast(types.DataTypes.DoubleType))
    if (isDebug) {
      dfTest.printSchema()
      dfTest.show(showNum, false)
      //println("Total test data count: %d".format(dfTest.count())) //Total test data count: 2345796
    }
    val duration = new Duration(start, new DateTime())
    println("finish import data, duration = %d".format(duration.getMillis))
    (dfTrain, dfTest)
  }

  def getTfIdfTransformer(numFeatures: Int, numPcaFeatures: Int): (HashingTF, IDF, PCA) = {
    val hashingTF = new HashingTF()
      .setInputCol("words").setOutputCol("rawFeatures").setNumFeatures(numFeatures)
    val idf = new IDF().setInputCol("rawFeatures").setOutputCol("features")
    
    val pca = new PCA().setInputCol("features").setOutputCol("pcaFeatures").setK(numPcaFeatures)
    (hashingTF, idf, pca)
  }

  def addTfidfFeatures(dfTrain: DataFrame, dfTest: DataFrame, numFeatures: Int, numPcaFeatures: Int, 
      isDebug: Boolean): (DataFrame, DataFrame) = {
    println("calculate tf-idf weight for train & test data ...")
    val start = new DateTime()
    val showNum = 3
    var wordsDf1 = dfTrain.select(col("id"),
      col("qid1"), col("words1").alias("words"), col("weight"), col("is_duplicate"), col("w2vWeight"), col("w2vWeight1k"))
    var wordsDf2 = dfTrain.select(col("id"), col("qid2"), col("words2").alias("words"))
    val wordsDfAll = wordsDf1.select("words")
      .union(wordsDf2.select("words")).filter(!col("words").isNull)
    var wordsDf1Test = dfTest.select(col("test_id"), col("words1").alias("words"), col("weight"), col("w2vWeight"), col("w2vWeight1k"))
    var wordsDf2Test = dfTest.select(col("test_id"), col("words2").alias("words"))

    val wordsDfAllTest = wordsDf1Test.select("words")
      .union(wordsDf2Test.select("words"))
    val (hashingTF, idf, pca) = getTfIdfTransformer(numFeatures, numPcaFeatures)
    val featurizedData = hashingTF.transform(wordsDfAll.union(wordsDfAllTest))
    val idfModel = idf.fit(featurizedData)
    wordsDf1 = idfModel.transform(hashingTF.transform(wordsDf1))
    wordsDf2 = idfModel.transform(hashingTF.transform(wordsDf2))
    wordsDf1Test = idfModel.transform(hashingTF.transform(wordsDf1Test))
    wordsDf2Test = idfModel.transform(hashingTF.transform(wordsDf2Test))
    
    val pcaModel = pca.fit(wordsDf1.select("features").union(wordsDf2.select("features"))
        .union(wordsDf1Test.select("features")).union(wordsDf2Test.select("features")))
    
        wordsDf1 = pcaModel.transform(wordsDf1)
        wordsDf2 = pcaModel.transform(wordsDf2)
        wordsDf1Test = pcaModel.transform(wordsDf1Test)
        wordsDf2Test = pcaModel.transform(wordsDf2Test)

    val trainTfidfData =
      wordsDf1.select(col("id"), col("qid1"), 
          /*col("features")*/col("pcaFeatures").alias("features1"), 
        col("weight").cast("double"), col("is_duplicate"), col("w2vWeight").cast("double"), col("w2vWeight1k").cast("double"))
        .join(wordsDf2.select(col("id"), col("qid2"), 
            /*col("features")*/col("pcaFeatures").alias("features2")),
          Seq("id")).drop("wordsDf2.id")

    val testTfidfData =
      wordsDf1Test.select(col("test_id"), 
          /*col("features")*/col("pcaFeatures").alias("features1"), col("weight").cast("double"),
        col("w2vWeight").cast("double"), col("w2vWeight1k").cast("double"))
        .join(wordsDf2Test.select(col("test_id"), 
            /*col("features")*/col("pcaFeatures").alias("features2")),
          Seq("test_id")).drop("wordsDf2Test.test_id")
    if (isDebug) {
      trainTfidfData.printSchema()
      //trainTfidfData.show(showNum)
      testTfidfData.printSchema()
    }
    val duration = new Duration(start, new DateTime())
    println("finish calculate tf-idf for train data & test data, duration = %d".format(duration.getMillis))
    (trainTfidfData, testTfidfData)
  }

  def calculateTfIdfForTrain(dfTrain: DataFrame, numFeatures: Int, numW2vFeatures: Int, isDebug: Boolean): DataFrame = {
    println("calculate tf-idf weight for train data ...")
    val start = new DateTime()
    val showNum = 3
    var wordsDf1 = dfTrain.select(col("id"),
      col("qid1"), col("words1").alias("words"), col("weight"), col("is_duplicate"), col("w2vWeight"), col("w2vWeight1k"))
    var wordsDf2 = dfTrain.select(col("id"), col("qid2"), col("words2").alias("words"))
    val (hashingTF, idf, _) = getTfIdfTransformer(numFeatures, 0)
    val wordsDfAll = wordsDf1.select("id", "words")
      .union(wordsDf2.select("id", "words")).filter(!col("words").isNull)
    val featurizedData = hashingTF.transform(wordsDfAll)
    val idfModel = idf.fit(featurizedData)
    wordsDf1 = idfModel.transform(hashingTF.transform(wordsDf1))
    wordsDf2 = idfModel.transform(hashingTF.transform(wordsDf2))

    val trainTfidfData =
      wordsDf1.select(col("id"), col("qid1"), col("features").alias("features1"),
        col("weight").cast("double"), col("is_duplicate"), col("w2vWeight").cast("double"), col("w2vWeight1k").cast("double"))
        .join(wordsDf2.select(col("id"), col("qid2"), col("features").alias("features2")),
          Seq("id")).drop("wordsDf2.id")
    if (isDebug) {
      trainTfidfData.printSchema()
      //trainTfidfData.show(showNum)
    }
    val duration = new Duration(start, new DateTime())
    println("finish calculate tf-idf for train data, duration = %d".format(duration.getMillis))
    trainTfidfData
  }

  def calculateTfIdfForTest(dfTest: DataFrame, numFeatures: Int, numW2vFeatures: Int, isDebug: Boolean): DataFrame = {
    val showNum = 3
    println("calculate tf-idf weight for test data ...")
    val start = new DateTime()
    var wordsDf1 = dfTest.select(col("test_id"), col("words1").alias("words"), col("weight"), col("w2vWeight"), col("w2vWeight1k"))
    var wordsDf2 = dfTest.select(col("test_id"), col("words2").alias("words"))
    val (hashingTF, idf, _) = getTfIdfTransformer(numFeatures,0)
    val wordsDfAll = wordsDf1.select("test_id", "words")
      .union(wordsDf2.select("test_id", "words"))
    val featurizedData = hashingTF.transform(wordsDfAll)
    val idfModel = idf.fit(featurizedData)
    wordsDf1 = idfModel.transform(hashingTF.transform(wordsDf1))
    wordsDf2 = idfModel.transform(hashingTF.transform(wordsDf2))

    val testTfidfData =
      wordsDf1.select(col("test_id"), col("features").alias("features1"), col("weight").cast("double"),
        col("w2vWeight").cast("double"), col("w2vWeight1k").cast("double"))
        .join(wordsDf2.select(col("test_id"), col("features").alias("features2")),
          Seq("test_id")).drop("wordsDf1.test_id")
    if (isDebug) {
      testTfidfData.printSchema()
      //testTfidfData.show(showNum)
    }
    val duration = new Duration(start, new DateTime())
    println("finish calculate tf-idf for test data, duration = %d".format(duration.getMillis))
    testTfidfData
  }

  def transferTrainDfToLabeledPoint(trainData: DataFrame, assemblerInputs: Array[String], isDebug: Boolean): RDD[MLLabeledPoint] = {
    val start = new DateTime()
    println("starting transfer train dataframe to RDD ...")

    val assembler: VectorAssembler = new VectorAssembler().setInputCols(assemblerInputs).setOutputCol("features")
    val featureDf = assembler.transform(trainData)
    if (isDebug)
      featureDf.show(3, false)
    val rtnRdd = featureDf.rdd.map(row => MLLabeledPoint(
      row.getAs[Double]("is_duplicate"),
      Utils.mlVectorToMllibVector(row.getAs[org.apache.spark.ml.linalg.Vector]("features"))))
    val duration = new Duration(start, new DateTime())
    println("finish transfer train dataframe to RDD, duration = %d".format(duration.getMillis))
    rtnRdd
  }

  def transferTestDfToLabeledPoint(testData: DataFrame, assemblerInputs: Array[String], isDebug: Boolean): RDD[MLLabeledPoint] = {
    val start = new DateTime()
    println("starting transfer test dataframe to RDD ...")
    val assembler: VectorAssembler = new VectorAssembler().setInputCols(assemblerInputs).setOutputCol("features")
    val featureDf = assembler.transform(testData)
    if (isDebug)
      featureDf.show(3, false)
    val rtnRdd = featureDf.rdd.map(row => MLLabeledPoint(
      row.getAs[String]("test_id").toDouble,
      Utils.mlVectorToMllibVector(row.getAs[org.apache.spark.ml.linalg.Vector]("features"))))
    val duration = new Duration(start, new DateTime())
    println("finish transfer test dataframe to RDD, duration = %d".format(duration.getMillis))
    rtnRdd
  }

  def doPredict(xgbModel: XGBoostModel, testRddOrg: RDD[MLLabeledPoint], nWorkers: Int, outputDir: String) = {
    val start = new DateTime()
    println("starting predict test RDD ...")
    val testRdd = testRddOrg /*.filter(f => f.label < 200)*/ .sortBy(f => f.label, true, 80 * nWorkers)
    val testSet = testRdd.map(f => f.features)
    //val idRdd = testRdd.map(f => f.label.toInt)
    //println("cnt1: %d, cnt2: %d".format(testSet.count(), idRdd.count()))
    //val matrix: DMatrix = new DMatrix(testRdd)
    val predRes = xgbModel.predict(testSet).flatMap(f => f.flatMap(f => f))
    //val outputRes = idRdd.zip(predRes).map(f => (f._1 + "," + f._2))
    val outputRes = predRes.zipWithIndex() /*.sortBy(f => f._2, true, 8*nWorkers)*/ .map(f => (f._2 + "," + f._1))
    //    val outputRes = idRdd.zipPartitions(predRes){
    //      (rdd1Iter,rdd2Iter) => {
    //        var result = List[String]()
    //              while(rdd1Iter.hasNext && rdd2Iter.hasNext) {
    //               result::=(rdd1Iter.next() + "," + rdd2Iter.next())
    //              }
    //              result.iterator
    //      }
    //    }
    //println("cnt1: %d, cnt2: %d".format(predRes.count(), outputRes.count()))
    outputRes.saveAsTextFile("%s".format(outputDir))
    val duration = new Duration(start, new DateTime())
    println("finish predict test RDD, duration = %d".format(duration.getMillis))
  }

  def trainXgbModel(trainRDD: RDD[MLLabeledPoint], numRound: Int, nWorkers: Int, maxDepth: Int): XGBoostModel = {
    val start = new DateTime()
    println("starting train model for train RDD ...")
    val paramMap = List(
      "eta" -> 0.05f,//0.02f
      "max_depth" -> maxDepth,
      "objective" -> "binary:logistic",
      "eval_metric" -> "logloss").toMap
    val xgboostModel = XGBoost.train(trainRDD.repartition(nWorkers), paramMap, numRound, nWorkers = nWorkers)
    val duration = new Duration(start, new DateTime())
    println("finish train model for train RDD, duration = %d".format(duration.getMillis))
    xgboostModel
  }

  def setLogger = {
    Logger.getLogger("org").setLevel(Level.OFF)
    Logger.getLogger("com").setLevel(Level.OFF)
    Logger.getLogger("io").setLevel(Level.OFF)
    //System.setProperty("spark.ui.showConsoleProgress", "false")
    Logger.getRootLogger().setLevel(Level.DEBUG);
  }
}