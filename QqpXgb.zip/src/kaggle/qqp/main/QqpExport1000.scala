package kaggle.qqp.main
import org.joda.time._
//log
import org.apache.log4j.Logger
import org.apache.log4j.Level
import org.apache.log4j._

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._
import org.apache.spark.rdd._

import kaggle.qqp.util._
import org.apache.spark.sql._
import org.apache.spark.sql.functions.{ col => col, split => split, when => when, udf => udf, lit => lit }

import org.apache.spark.ml.feature.{ HashingTF, IDF, Word2Vec, Word2VecModel, VectorAssembler }
import org.apache.spark.ml.{ Pipeline, PipelineModel }
import org.apache.spark.ml.param.ParamMap

import breeze.linalg._
import org.apache.spark.mllib.linalg.{ DenseVector => MLDenseVector }
import org.apache.spark.mllib.regression.{ LabeledPoint => MLLabeledPoint }
import org.apache.spark.mllib.util.MLUtils
import kaggle.qqp.util.Utils

object QqpExport1000 {
  case class TrainPair(id: Long, qid1: String, words1: String, qid2: String, words2: String, is_duplicate: Double, weight: Double, w2vWeight: Double, w2vDist1k: Double)
  case class TestPair(test_id: Long, words1: String, words2: String, weight: Double, w2vWeight: Double, w2vDist1k: Double)

  def main(args: Array[String]): Unit = {
    if (args == null || args.size != 6) {
      println("[Error]Need 5 args: <masterUrl> <trainFilePath> <testFilePath> <outputPath> <googleW2vPath> <isDebug>")
      return
    }
    val masterUrl = args(0)
    val trainFilePath = args(1)
    val testFilePath = args(2)
    val outputDir = args(3)
    val gooW2vPath = args(4)
    val isDebug = args(5).equals("Y")

    setLogger

    val spark = Utils.createSparkSession(masterUrl, "Kaggle QuoraQuestion Export W2v1000Weight")
    import spark.implicits._
    val (trainData, testData) = prepareData(spark, trainFilePath, testFilePath, isDebug)

    //read googleW2vVector to Rdd
    val gooW2v = getW2vVector(spark.sparkContext, gooW2vPath)
    //gooW2v.take(3).foreach(f => println("%s: [%s]".format(f._1, f._2.mkString(","))))

    //getWordPairs for train Data
    val trainRdd = trainData.rdd.map {
      row =>
        (row.getAs[String]("id").toLong,
          row.getAs[String]("qid1"), row.getAs[String]("words1"),
          row.getAs[String]("qid2"), row.getAs[String]("words2"),
          row.getAs[Double]("is_duplicate"), row.getAs[Double]("weight"), row.getAs[Double]("w2vWeight"))
    }
    val wordPairsTrain = trainRdd
      .flatMap { case (id, qid1, words1, qid2, words2, is_duplicate, weight, w2vWeight) => 
        getWordPairs(id, words1, words2) }

    //wordPairsTrain.take(3).foreach(f => println("%s: [%s, %s]".format(f._1, f._2._1, f._2._2)))  

//        val testRdd = spark.sparkContext.parallelize(Seq(
//            (1L, "glass-cider", "full-cup-apple-juice", 0d),
//            (2L, "canis-familiaris-animals", "dogs-common-pets", 0d),
//            (3L, "dog",	"must-be-your-dog", 0d),
//            (4L, "john-very-nice","john-very-nice", 0d)
//            ))
    val testRdd = testData.rdd.map {
      row =>
        (row.getAs[String]("test_id").toLong,
          row.getAs[String]("words1"), row.getAs[String]("words2"),
          row.getAs[Double]("weight"), row.getAs[Double]("w2vWeight"))
    }
    val wordPairsTest = testRdd
      .flatMap { case (test_id, words1, words2, weight, w2vWeight) => getWordPairs(test_id, words1, words2) }
    //wordPairsTest.take(3).foreach(f => println("%s: [%s, %s]".format(f._1, f._2._1, f._2._2)))

    println("generate word vectors of train data ...")
    val wordVectorsTrain = wordPairsTrain.map({
      case (idx, (lword, rword)) =>
        (rword, (idx, lword))
    })
      .join(gooW2v) // (rword, ((idx, lword), rvec))
      .map({ case (rword, ((idx, lword), rvec)) => (lword, (idx, rvec)) })
      .join(gooW2v) // (lword, ((idx, rvec), lvec))
      .map({ case (lword, ((idx, rvec), lvec)) => ((idx, lword), (lvec, rvec)) })
      .map({
        case ((idx, lword), (lvec, rvec)) =>
          ((idx, lword), List(dist(lvec, rvec)))
      })
      .persist(org.apache.spark.storage.StorageLevel.MEMORY_AND_DISK)

    println("generate word vectors of test data ...")
    val wordVectorsTest = wordPairsTest.map({
      case (idx, (lword, rword)) =>
        (rword, (idx, lword))
    })
      .join(gooW2v) // (rword, ((idx, lword), rvec))
      .map({ case (rword, ((idx, lword), rvec)) => (lword, (idx, rvec)) })
      .join(gooW2v) // (lword, ((idx, rvec), lvec))
      .map({ case (lword, ((idx, rvec), lvec)) => ((idx, lword), (lvec, rvec)) })
      .map({
        case ((idx, lword), (lvec, rvec)) =>
          ((idx, lword), List(dist(lvec, rvec)))
      })
      .persist(org.apache.spark.storage.StorageLevel.MEMORY_AND_DISK)

    println("calculate best WMDs for train data...")
    val bestWMDsTrain = wordVectorsTrain.reduceByKey((a, b) => a ++ b)
      .mapValues(dists => dists.sortWith(_ < _).head) // dist to closest word
      .map({ case ((idx, lword), wmd) => (idx, wmd) })
      .reduceByKey((a, b) => a + b)

    println("calculate best WMDs for Test data...")
    val bestWMDsTest = wordVectorsTest.reduceByKey((a, b) => a ++ b)
      .mapValues(dists => dists.sortWith(_ < _).head) // dist to closest word
      .map({ case ((idx, lword), wmd) => (idx, wmd) })
      .reduceByKey((a, b) => a + b)

    var trainRddCount = 0L; var testRddCount = 0L
    if (isDebug) {
      val wordPairsTrainDis = wordPairsTrain.map(f => f._1).distinct()
      trainRddCount = trainRdd.count()
      val wpTrainCnt = wordPairsTrainDis.count()
      println("train count: %d, word pairs distinct count: %d".format(trainRddCount, wpTrainCnt))
      if (trainRddCount != wpTrainCnt) {
        println("[1]diff id: ")
        trainRdd.map(f => f._1).subtract(wordPairsTrainDis).take(5).foreach { x => println(x) }
      }
      val wmdTrainDis = bestWMDsTrain.map(f => f._1).distinct()
      val wmdTrainDisCnt = wmdTrainDis.count()
      if (trainRddCount != wmdTrainDisCnt) {
        println("[2]diff id: ")
        trainRdd.map(f => f._1).subtract(wmdTrainDis).take(5).foreach { x => println(x) }
      }
      
      val wordPairsTestDis = wordPairsTest.map(f => f._1).distinct()
      testRddCount = testRdd.count()
      val wpTestCnt = wordPairsTestDis.count()
      println("test count: %d, word pairs distinct count: %d".format(testRddCount, wpTestCnt))
      if (testRddCount != wpTestCnt) {
        println("[1]diff test_id: ")
        testRdd.map(f => f._1).subtract(wordPairsTestDis).take(5).foreach { x => println(x) }
      }
      val wmdTestDis = bestWMDsTest.map(f => f._1).distinct()
      val wmdTestDisCnt = wmdTestDis.count()
      if (testRddCount != wmdTestDisCnt) {
        println("[2]diff test_id: ")
        testRdd.map(f => f._1).subtract(wmdTestDis).take(5).foreach { x => println(x) }
      }
    }//if (isDebug) {
    
    
    val resultsTrain = trainRdd.map(f => (f._1, (f._2, f._3, f._4, f._5, f._6, f._7, f._8)))
      .leftOuterJoin(bestWMDsTrain)
      .map({
        case (id, ((qid1, words1, qid2, words2, is_duplicate, weight, w2vWeight), wmd)) =>
          TrainPair(id, qid1, words1, qid2, words2, is_duplicate, weight, w2vWeight, if (wmd.isEmpty) 999d else wmd.get)
      })
    val trainPreFinal = resultsTrain.toDF
      .orderBy($"id".asc)
    trainPreFinal.printSchema()
    trainPreFinal.show(5)
    val trainFinal = normalizeW2v(trainPreFinal)

    val resultsTest = testRdd.map(f => (f._1, (f._2, f._3, f._4, f._5)))
      .leftOuterJoin(bestWMDsTest)
      .map({ case (test_id, ((s1, s2, weight, w2vWeight), wmd)) => TestPair(test_id, s1, s2, weight, w2vWeight, if (wmd.isEmpty) 999d else wmd.get) })
    val testPreFinal = resultsTest.toDF
      .orderBy($"test_id".asc)
    testPreFinal.printSchema()
    testPreFinal.show(5)
    val testFinal = normalizeW2v(testPreFinal)

    trainFinal.describe("w2vWeight", "w2vWeight1k").show()
    testFinal.describe("w2vWeight","w2vWeight1k").show()

    if (!isDebug) {
      trainFinal.printSchema()
      trainFinal.write.csv(outputDir + "/trainFinal")
      testFinal.printSchema()
      testFinal.write.csv(outputDir + "/testFinal")  
    }
    
    println("finish ...")
  }

  def normalizeW2v(df: DataFrame): DataFrame = {
    println("normalizeW2v W2v weight for data ...")
    val start = new DateTime()
    //    val normalize = udf((origWeight: Double, min: Double, max: Double) => {
    //      val nWeight = (origWeight) / (max - min)
    //      nWeight
    //    })
    //
    //    val descDup = df.describe("w2vDist")
    //    val descMin = descDup.filter("summary='min'").select("w2vDist").collect()(0).getAs[String](0).toDouble
    //    val descMax = descDup.filter("summary='max'").select("w2vDist").collect()(0).getAs[String](0).toDouble

    //val rtnDf = df.withColumn("w2vWeight", normalize(col("w2vDist"), lit(descMin), lit(descMax)))
    val rtnDf = df.withColumn("w2vWeight1k", col("w2vDist1k")).drop("w2vDist1k", "w2vDist")
    val duration = new Duration(start, new DateTime())
    println("finish normalize w2v Weight for train data, duration = %d".format(duration.getMillis))
    rtnDf
  }

  def dist(lvec: Array[Double], rvec: Array[Double]): Double = {
    val lv = DenseVector(lvec)
    val rv = DenseVector(rvec)
    math.sqrt(sum((lv - rv) :* (lv - rv)))
  }

  def getWordPairs(id: Long, s1: String, s2: String): List[(Long, (String, String))] = {
    val s1o = Option(s1)
    val s2o = Option(s2)
    val w1s = if (s1o.exists(_.trim.nonEmpty)) s1o.get.split("-") else Array("NoValue")
    val w2s = if (s2o.exists(_.trim.nonEmpty)) s2o.get.split("-") else Array("NoValue")
    val wpairs = for (w1 <- w1s; w2 <- w2s) yield (id, (w1, w2))
    wpairs.toList
  }

  def getW2vVector(sc: SparkContext, gooW2vPath: String): RDD[(String, Array[Double])] = {
    val gooW2vVec = sc.textFile(gooW2vPath)
    val gooW2v = gooW2vVec.flatMap(line => line.split("\t")).map(line => line.split(" "))
      .filter(fields => fields.length > 2)
      .map(fields => (/*fields(0)*/fields(0).split("/")(2), fields.slice(1, fields.length).map { x => x.toDouble }))
    gooW2v
  }

  def setLogger = {
    Logger.getLogger("org").setLevel(Level.OFF)
    Logger.getLogger("com").setLevel(Level.OFF)
    Logger.getLogger("io").setLevel(Level.OFF)
    System.setProperty("spark.ui.showConsoleProgress", "false")
    Logger.getRootLogger().setLevel(Level.DEBUG);
  }

  def prepareData(spark: SparkSession, trainFilePath: String, testFilePath: String, isDebug: Boolean): (DataFrame, DataFrame) = {
    val showNum = 3
    val start = new DateTime()
    println("importing train data ...")
    val df = Utils.readCSV(spark, trainFilePath)
    val dfTrain = df.select(col("id"),
      col("qid1"), col("words1"), col("qid2"), col("words2"),
      col("is_duplicate").cast(types.DataTypes.DoubleType),
      col("weight").cast(types.DataTypes.DoubleType), col("w2vWeight").cast(types.DataTypes.DoubleType))
    if (isDebug) {
      dfTrain.printSchema()
      dfTrain.show(showNum, false)
      //println("Total train data count: %d".format(dfTrain.count())) //Total train data count: 404290
    }

    println("importing test data ...")
    val df2 = Utils.readCSV(spark, testFilePath)
    val dfTest = df2.select(col("test_id"),
      col("words1"), col("words2"),
      col("weight").cast(types.DataTypes.DoubleType), col("w2vWeight").cast(types.DataTypes.DoubleType))
    if (isDebug) {
      dfTest.printSchema()
      dfTest.show(showNum, false)
      //println("Total test data count: %d".format(dfTest.count())) //Total test data count: 2345796
    }
    val duration = new Duration(start, new DateTime())
    println("finish import data, duration = %d".format(duration.getMillis))
    (dfTrain, dfTest)
  }
}