package kaggle.qqp.main
//time lib
import org.joda.time._
//log
import org.apache.log4j.Logger
import org.apache.log4j.Level
import org.apache.log4j._

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._
import org.apache.spark.rdd._

import kaggle.qqp.util._
import org.apache.spark.sql._
import org.apache.spark.sql.functions.{ col => col, split => split, when => when, udf => udf }

import org.apache.spark.ml.feature.{ HashingTF, IDF, VectorAssembler }
import org.apache.spark.ml.{ Pipeline, PipelineModel }
import org.apache.spark.ml.param.ParamMap
import org.apache.spark.ml.classification.{ RandomForestClassifier, RandomForestClassificationModel }
import org.apache.spark.ml.tuning.{ CrossValidator, CrossValidatorModel, ParamGridBuilder }
import org.apache.spark.ml.evaluation.BinaryClassificationEvaluator

import org.apache.spark.ml.linalg.Vector

import ml.dmlc.xgboost4j.scala.XGBoost

object QqpTfIdf {
  def main(args: Array[String]): Unit = {
    if (args == null || args.size != 5) {
      println("[Error]Need 4 args: <masterUrl> <trainFilePath> <testFilePath> <outputDir> <debug(Y/N)> ")
      return
    }

    setLogger
    val numFeatures = 128
    val masterUrl = args(0)
    val trainFilePath = args(1)
    val testFilePath = args(2)
    val outputDir = args(3)
    val isDebug = "Y".equals(args(4))

    val spark = Utils.createSparkSession(masterUrl, "Kaggle QuoraQuestion")
    val (trainData, testData) = prepareData(spark, trainFilePath, testFilePath, isDebug)
    val trainTfIdfData = calculateTfIdfForTrain(trainData, numFeatures, isDebug)
    val testTfIdfData = calculateTfIdfForTest(testData, numFeatures, isDebug)
    //trainWithMlModel(trainTfIdfData, isDebug)
    predictWithMlModel(trainTfIdfData, testTfIdfData, outputDir, isDebug)
  }

  def prepareData(spark: SparkSession, trainFilePath: String, testFilePath: String, isDebug: Boolean): (DataFrame, DataFrame) = {
    val showNum = 3
    val start = new DateTime()
    println("importing train data ...")
    val df = Utils.readCSV(spark, trainFilePath)
    val dfTrain = df.select(col("id"),
      col("qid1"), when(col("words1") !== (""), split(col("words1"), "-")).otherwise(Array(".")).alias("words1"),
      col("qid2"), when(col("words2") !== "", split(col("words2"), "-")).otherwise(Array(".")).alias("words2"),
      col("is_duplicate").cast(types.DataTypes.DoubleType),
      col("weight").cast(types.DataTypes.DoubleType))
    if (isDebug) {
      dfTrain.printSchema()
      dfTrain.show(showNum, false)
      //println("Total train data count: %d".format(dfTrain.count())) //Total train data count: 404290
    }

    println("importing test data ...")
    val df2 = Utils.readCSV(spark, testFilePath)
    val dfTest = df2.select(col("test_id"),
      when(col("words1") !== (""), split(col("words1"), "-")).otherwise(Array(".")).alias("words1"),
      when(col("words2") !== "", split(col("words2"), "-")).otherwise(Array(".")).alias("words2"),
      col("weight").cast(types.DataTypes.DoubleType))
    if (isDebug) {
      dfTest.printSchema()
      dfTest.show(showNum, false)
      //println("Total test data count: %d".format(dfTest.count())) //Total test data count: 2345796
    }
    val duration = new Duration(start, new DateTime())
    println("finish import data, duration = %d".format(duration.getMillis))
    (dfTrain, dfTest)
  }

  def getTfIdfTransformer(numFeatures: Int): (HashingTF, IDF) = {
    val hashingTF = new HashingTF()
      .setInputCol("words").setOutputCol("rawFeatures").setNumFeatures(numFeatures)
    val idf = new IDF().setInputCol("rawFeatures").setOutputCol("features")
    (hashingTF, idf)
  }

  def calculateTfIdfForTrain(dfTrain: DataFrame, numFeatures: Int, isDebug: Boolean): DataFrame = {
    println("calculate tf-idf weight for train data ...")
    val start = new DateTime()
    val showNum = 3
    var wordsDf1 = dfTrain.select(col("id"),
      col("qid1"), col("words1").alias("words"), col("weight"), col("is_duplicate"))
    var wordsDf2 = dfTrain.select(col("id"), col("qid2"), col("words2").alias("words"))
    val (hashingTF, idf) = getTfIdfTransformer(numFeatures)
    val featurizedData = hashingTF.transform(
      wordsDf1.select("id", "words")
        .union(wordsDf2.select("id", "words")).filter(!col("words").isNull))
    val idfModel = idf.fit(featurizedData)
    wordsDf1 = idfModel.transform(hashingTF.transform(wordsDf1))
    wordsDf2 = idfModel.transform(hashingTF.transform(wordsDf2))
    val trainTfidfData =
      wordsDf1.select(col("id"), col("qid1"), col("features").alias("features1"),
        col("weight").cast("double"), col("is_duplicate"))
        .join(wordsDf2.select(col("id"), col("qid2"), col("features").alias("features2")),
          Seq("id")).drop("wordsDf2.id")
    if (isDebug) {
      trainTfidfData.printSchema()
      //trainTfidfData.show(showNum)
    }
    val duration = new Duration(start, new DateTime())
    println("finish calculate tf-idf for train data, duration = %d".format(duration.getMillis))
    trainTfidfData
  }

  def calculateTfIdfForTest(dfTest: DataFrame, numFeatures: Int, isDebug: Boolean): DataFrame = {
    val showNum = 3
    println("calculate tf-idf weight for test data ...")
    val start = new DateTime()
    var wordsDf1 = dfTest.select(col("test_id"), col("words1").alias("words"), col("weight"))
    var wordsDf2 = dfTest.select(col("test_id"), col("words2").alias("words"))
    val (hashingTF, idf) = getTfIdfTransformer(numFeatures)
    val featurizedData = hashingTF.transform(wordsDf1.select("test_id", "words")
      .union(wordsDf2.select("test_id", "words")))
    val idfModel = idf.fit(featurizedData)
    wordsDf1 = idfModel.transform(hashingTF.transform(wordsDf1))
    wordsDf2 = idfModel.transform(hashingTF.transform(wordsDf2))
    val testTfidfData =
      wordsDf1.select(col("test_id"), col("features").alias("features1"), col("weight").cast("double"))
        .join(wordsDf2.select(col("test_id"), col("features").alias("features2")),
          Seq("test_id")).drop("wordsDf1.test_id")
    if (isDebug) {
      testTfidfData.printSchema()
      //testTfidfData.show(showNum)
    }
    val duration = new Duration(start, new DateTime())
    println("finish calculate tf-idf for test data, duration = %d".format(duration.getMillis))
    testTfidfData
  }

  def splitTrainData(trainData: DataFrame): (DataFrame, DataFrame) = {
    println("Split train data into trainSet and validSet ...")
    val start = new DateTime()
    val weights = Array(0.9, 0.1)
    val seed = 1126
    val trainData0 = trainData.filter("is_duplicate=0")
    val trainData1 = trainData.filter("is_duplicate=1")
    val train0S = trainData0.randomSplit(weights, seed)
    val train1S = trainData1.randomSplit(weights, seed)
    val duration = new Duration(start, new DateTime())
    println("finish split train data, duration = %d".format(duration.getMillis))
    (train0S(0).union(train1S(0)), train0S(1).union(train1S(1)))
  }

  def trainWithMlModel(trainData: DataFrame, isDebug: Boolean) = {
    val assemblerInputs = Array("weight", "features1", "features2")
    val assembler: VectorAssembler = new VectorAssembler().setInputCols(assemblerInputs).setOutputCol("features")
    var rf = new RandomForestClassifier().setFeaturesCol("features").setLabelCol("is_duplicate")
    val cvPipeline = new Pipeline().setStages(Array(assembler, rf))
    val paramGrid = new ParamGridBuilder()
      .addGrid(rf.numTrees, Array( /*5 ,*/ 8))
      .addGrid(rf.impurity, Array("gini", "entropy"))
      .addGrid(rf.maxDepth, Array( /*20,*/ 25 /*, 30*/ ))
      .addGrid(rf.maxBins, Array( /*10,*/ 15 /*, 20*/ )).build()
    val evaluator = new BinaryClassificationEvaluator()
      .setRawPredictionCol("probability").setLabelCol("is_duplicate").setMetricName("areaUnderROC")
    val cv = new CrossValidator()
      .setEstimator(cvPipeline).setEvaluator(evaluator).setEstimatorParamMaps(paramGrid)
      .setNumFolds(2)
    val (trainDataT, trainDataV) = splitTrainData(trainData)
    println("process cross validation to get best model ...")
    var start = new DateTime()
    val cvPipeModel = cv.fit(trainDataT.toDF())
    val duration = new Duration(start, new DateTime())
    println("finish train best model, duration = %d".format(duration.getMillis))
    start = new DateTime()
    val predictions = cvPipeModel.transform(trainDataV)
    val auc = evaluator.evaluate(predictions)
    if (isDebug) {
      println("best Params from cv: %s".format(makeStringForParamMap(extractBestParam(cvPipeModel))))
      //best Params from cv: impurity: gini, numTrees: 8, maxDepth: 25, maxBins: 15, auc: 0.832028
    }
    println("best auc for train validation: %f, duration: %d".format(auc, new Duration(start, new DateTime()).getMillis))
  }

  def makeStringForParamMap(paramMap: ParamMap): String = {
    paramMap.toSeq.map { x => "%s: %s".format(x.param.name.toString(), x.value.toString()) }.mkString(", ")
  }

  def extractBestParam(cvModel: CrossValidatorModel): ParamMap = {
    cvModel.getEstimatorParamMaps.zip(cvModel.avgMetrics).maxBy(_._2)._1
  }

  def predictWithMlModel(trainData: DataFrame, testData: DataFrame, outputDir: String, isDebug: Boolean) = {
    val assemblerInputs = Array("weight", "features1", "features2")
    val assembler: VectorAssembler = new VectorAssembler().setInputCols(assemblerInputs).setOutputCol("features")
    var rf = new RandomForestClassifier().setFeaturesCol("features").setLabelCol("is_duplicate")
      .setNumTrees(10).setImpurity("gini").setMaxDepth(30).setMaxBins(20)
    val pipeline = new Pipeline().setStages(Array(assembler, rf))
    val getFirstElement = udf((vec: org.apache.spark.ml.linalg.Vector) => vec(1))
    println("starting train pipeline model with Rf(mpurity: gini, numTrees: 8, maxDepth: 25, maxBins: 15)...")
    var start = new DateTime()
    val pipelineModel = pipeline.fit(trainData)
    println("finish train Rf pipeline, duration = %d".format(new Duration(start, new DateTime()).getMillis))
    println("starting predict testing data with Rf")
    start = new DateTime()
    val predictRes = pipelineModel.transform(testData)
    println("finish predict test result, duration = %d".format(new Duration(start, new DateTime()).getMillis))
    if (isDebug) {
      predictRes.printSchema()
      println("Total test prediction result count: %d".format(predictRes.count()))
    }
    println("start writing predict test result ...")
    start = new DateTime()
    predictRes.select(col("test_id").cast(types.DataTypes.IntegerType), 
        getFirstElement(col("probability")).alias("is_duplicate"))
        .orderBy(col("test_id"))
      .write.csv("%s/submit5.csv".format(outputDir))
    println("finish write predict test result, duration = %d".format(new Duration(start, new DateTime()).getMillis))
  }

  def setLogger = {
    Logger.getLogger("org").setLevel(Level.OFF)
    Logger.getLogger("com").setLevel(Level.OFF)
    Logger.getLogger("io").setLevel(Level.OFF)
    //System.setProperty("spark.ui.showConsoleProgress", "false")
    Logger.getRootLogger().setLevel(Level.DEBUG);
  }
}