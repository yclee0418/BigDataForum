package kaggle.qqp.main
import org.joda.time._
//log
import org.apache.log4j.Logger
import org.apache.log4j.Level
import org.apache.log4j._

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._
import org.apache.spark.rdd._

import kaggle.qqp.util._
import org.apache.spark.sql._
import org.apache.spark.sql.functions.{ col => col, split => split, when => when, udf => udf, lit => lit, asc => asc }

import org.apache.spark.ml.feature.{ HashingTF, IDF, Word2Vec, Word2VecModel, VectorAssembler }
import org.apache.spark.ml.{ Pipeline, PipelineModel }
import org.apache.spark.ml.param.ParamMap

import ml.dmlc.xgboost4j.scala.{ Booster, DMatrix }
import ml.dmlc.xgboost4j.scala.spark.{ DataUtils, XGBoost, XGBoostModel }
import org.apache.spark.mllib.linalg.{ DenseVector => MLDenseVector }
import org.apache.spark.mllib.regression.{ LabeledPoint => MLLabeledPoint }
import org.apache.spark.mllib.util.MLUtils
object QqpExport {
  def main(args: Array[String]): Unit = {
    if (args == null || args.size != 5) {
      println("[Error]Need 5 args: <masterUrl> <trainFilePath> <testFilePath> <outputPath> <numFeature>")
      return
    }
    val masterUrl = args(0)
    val trainFilePath = args(1)
    val testFilePath = args(2)
    val outputDir = args(3)
    val numW2vFeatures = args(4).toInt
    val isDebug = true

    val spark = Utils.createSparkSession(masterUrl, "Kaggle QuoraQuestion Export W2vWeight")
    val (rawTrainData, rawTestData, trainData, testData) = prepareData(spark, trainFilePath, testFilePath, isDebug)

    val trainW2vData = calculateW2VForTrain(trainData, numW2vFeatures, isDebug)
    val testTW2vData = calculateW2VForTest(testData, numW2vFeatures, isDebug)

    val trainW2vDf = normalizeW2v(trainW2vData)
    val trainFinal = trainW2vDf.select("id", "w2vWeight").join(rawTrainData, Seq("id")).drop("trainW2vDf.id")
      .select(col("id").cast(types.DataTypes.IntegerType),
        col("qid1"), col("words1"), col("qid2"), col("words2"), col("is_duplicate"), col("weight"), col("w2vWeight"))
      .orderBy(asc("id"))
    val testW2vDf = normalizeW2v(testTW2vData)
    val testFinal = testW2vDf.select("test_id", "w2vWeight").join(rawTestData, Seq("test_id")).drop("testW2vDf.test_id")
      .select(col("test_id").cast(types.DataTypes.IntegerType),
        col("words1"), col("words2"), col("weight"), col("w2vWeight"))
      .orderBy(asc("test_id"))
    trainFinal.printSchema()
    trainFinal.describe("w2vWeight").show()
    testFinal.printSchema()
    testFinal.describe("w2vWeight").show()

    trainFinal.write.csv(outputDir + "/trainFinal")
    testFinal.write.csv(outputDir + "/testFinal")

    println("finish ...")
  }
  //*******  w2v col = 20**********************************************
  //  +-------+-------------------+
  //|summary|          w2vWeight|
  //+-------+-------------------+
  //|  count|             404290|
  //|   mean|   0.98385877933518|
  //| stddev|0.02082045949893594|
  //|    min|                0.0|
  //|    max|                1.0|
  //+-------+-------------------+
  //  +-------+-------------------+
  //|summary|          w2vWeight|
  //+-------+-------------------+
  //|  count|            2345796|
  //|   mean| 0.9794482571198284|
  //| stddev|0.02215454242449221|
  //|    min|                0.0|
  //|    max|                1.0|
  //+-------+-------------------+
  //*******  w2v col = 128**********************************************
  //  +-------+--------------------+
  //|summary|           w2vWeight|
  //+-------+--------------------+
  //|  count|              404290|
  //|   mean|  0.9681414761001076|
  //| stddev|0.030760054017637605|
  //|    min|                 0.0|
  //|    max|                 1.0|
  //+-------+--------------------+
  //+-------+-------------------+
  //|summary|          w2vWeight|
  //+-------+-------------------+
  //|  count|            2345796|
  //|   mean| 0.9609266224713511|
  //| stddev|0.03462869035207435|
  //|    min|                0.0|
  //|    max|                1.0|
  //+-------+-------------------+

  def normalizeW2v(df: DataFrame): DataFrame = {
    println("normalizeW2v W2v weight for data ...")
    val start = new DateTime()
    val normalize = udf((origWeight: Double, min: Double, max: Double) => {
      val nWeight = (origWeight) / (max - min)
      nWeight
    })

    val descDup = df.describe("w2vDist")
    val descMin = descDup.filter("summary='min'").select("w2vDist").collect()(0).getAs[String](0).toDouble
    val descMax = descDup.filter("summary='max'").select("w2vDist").collect()(0).getAs[String](0).toDouble

    val rtnDf = df.withColumn("w2vWeight", normalize(col("w2vDist"), lit(descMin), lit(descMax)))
    val duration = new Duration(start, new DateTime())
    println("finish normalize w2v Weight for train data, duration = %d".format(duration.getMillis))
    rtnDf
  }

  def setLogger = {
    Logger.getLogger("org").setLevel(Level.OFF)
    Logger.getLogger("com").setLevel(Level.OFF)
    Logger.getLogger("io").setLevel(Level.OFF)
    System.setProperty("spark.ui.showConsoleProgress", "false")
    Logger.getRootLogger().setLevel(Level.DEBUG);
  }

  def prepareData(spark: SparkSession, trainFilePath: String, testFilePath: String, isDebug: Boolean): (DataFrame, DataFrame, DataFrame, DataFrame) = {
    val showNum = 3
    val start = new DateTime()
    println("importing train data ...")
    val df = Utils.readCSV(spark, trainFilePath)
    val dfTrain = df.select(col("id"),
      col("qid1"), when(col("words1") !== (""), split(col("words1"), "-")).otherwise(Array(".")).alias("words1"),
      col("qid2"), when(col("words2") !== "", split(col("words2"), "-")).otherwise(Array(".")).alias("words2"),
      col("is_duplicate").cast(types.DataTypes.DoubleType),
      col("weight").cast(types.DataTypes.DoubleType))
    if (isDebug) {
      dfTrain.printSchema()
      dfTrain.show(showNum, false)
      //println("Total train data count: %d".format(dfTrain.count())) //Total train data count: 404290
    }

    println("importing test data ...")
    val df2 = Utils.readCSV(spark, testFilePath)
    val dfTest = df2.select(col("test_id"),
      when(col("words1") !== (""), split(col("words1"), "-")).otherwise(Array(".")).alias("words1"),
      when(col("words2") !== "", split(col("words2"), "-")).otherwise(Array(".")).alias("words2"),
      col("weight").cast(types.DataTypes.DoubleType))
    if (isDebug) {
      dfTest.printSchema()
      dfTest.show(showNum, false)
      //println("Total test data count: %d".format(dfTest.count())) //Total test data count: 2345796
    }
    val duration = new Duration(start, new DateTime())
    println("finish import data, duration = %d".format(duration.getMillis))
    (df, df2, dfTrain, dfTest)
  }

  def getWord2VecTransformer(numW2VFeatures: Int): Word2Vec = {
    val word2Vec = new Word2Vec()
      .setInputCol("words")
      .setOutputCol("featuresW2V")
      .setVectorSize(numW2VFeatures)
      .setMinCount(2)
    word2Vec
  }

  def getW2VModel(df: DataFrame, numW2vFeatures: Int, isDebug: Boolean): Word2VecModel = {
    val w2v = getWord2VecTransformer(numW2vFeatures)
    val w2vModel = w2v.fit(df)
    w2vModel
  }

  def calculateW2vDistance(df: DataFrame, isDebug: Boolean): DataFrame = {
    val calculateDistance = udf((vec1: org.apache.spark.ml.linalg.Vector, vec2: org.apache.spark.ml.linalg.Vector) => {
      val dist = org.apache.spark.ml.linalg.Vectors.sqdist(vec1, vec2)
      dist
    })
    val newDf = df.withColumn("w2vDist", calculateDistance(col("featuresWv1"), col("featuresWv2"))).drop("featuresWv1", "featuresWv2")
    if (isDebug) {
      newDf.printSchema()
    }
    newDf
  }

  def calculateW2VForTrain(dfTrain: DataFrame, numW2vFeatures: Int, isDebug: Boolean): DataFrame = {
    println("calculate w2v weight for train data ...")
    val start = new DateTime()
    val showNum = 3
    var wordsDf1 = dfTrain.select(col("id"),
      col("qid1"), col("words1").alias("words"), col("weight"), col("is_duplicate"))
    var wordsDf2 = dfTrain.select(col("id"), col("qid2"), col("words2").alias("words"))
    val wordsDfAll = wordsDf1.select("id", "words")
      .union(wordsDf2.select("id", "words")).filter(!col("words").isNull)

    //Add Word2Vec feature
    val w2vModel = getW2VModel(wordsDfAll, numW2vFeatures, isDebug)
    wordsDf1 = w2vModel.transform(wordsDf1)
    wordsDf2 = w2vModel.transform(wordsDf2)

    val trainW2vData =
      wordsDf1.select(col("id"), col("qid1"), col("words").alias("words1"),
        col("weight").cast("double"), col("is_duplicate"), col("featuresW2V").alias("featuresWv1"))
        .join(wordsDf2.select(col("id"), col("qid2"), col("words").alias("words2"),
          col("featuresW2V").alias("featuresWv2")),
          Seq("id")).drop("wordsDf2.id")

    val trainW2vDataFinal = calculateW2vDistance(trainW2vData, isDebug)
    if (isDebug) {
      trainW2vDataFinal.printSchema()
    }
    val duration = new Duration(start, new DateTime())
    println("finish calculate W2v for train data, duration = %d".format(duration.getMillis))
    trainW2vDataFinal
  }

  def calculateW2VForTest(dfTest: DataFrame, numW2vFeatures: Int, isDebug: Boolean): DataFrame = {
    val showNum = 3
    println("calculate W2v weight for test data ...")
    val start = new DateTime()
    var wordsDf1 = dfTest.select(col("test_id"), col("words1").alias("words"), col("weight"))
    var wordsDf2 = dfTest.select(col("test_id"), col("words2").alias("words"))
    val wordsDfAll = wordsDf1.select("test_id", "words")
      .union(wordsDf2.select("test_id", "words"))

    //Add Word2Vec feature
    val w2vModel = getW2VModel(wordsDfAll, numW2vFeatures, isDebug)
    wordsDf1 = w2vModel.transform(wordsDf1)
    wordsDf2 = w2vModel.transform(wordsDf2)

    val testW2vData =
      wordsDf1.select(col("test_id"), col("words").alias("words1"), col("weight").cast("double"),
        col("featuresW2V").alias("featuresWv1"))
        .join(wordsDf2.select(col("test_id"), col("words").alias("words2"), col("featuresW2V").alias("featuresWv2")),
          Seq("test_id")).drop("wordsDf1.test_id")

    val testW2vDataFinal = calculateW2vDistance(testW2vData, isDebug)
    if (isDebug) {
      testW2vDataFinal.printSchema()
    }
    val duration = new Duration(start, new DateTime())
    println("finish calculate W2v for test data, duration = %d".format(duration.getMillis))
    testW2vDataFinal
  }
}